# Garmin Ant Agent
[Garmin Ant Agent](http://www8.garmin.com/fitness/ant_product_page.jsp) Garmin ANT Agent allows you to transfer fitness data from compatible Garmin ANT devices to and from your computer.

## Usage

```puppet
include garmin_ant_agent
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
