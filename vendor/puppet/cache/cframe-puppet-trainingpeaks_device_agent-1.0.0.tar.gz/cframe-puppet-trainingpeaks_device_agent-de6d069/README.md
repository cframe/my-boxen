# TrainingPeaks Device Agent
[TrainingPeaks Device Agent](http://support.trainingpeaks.com/device-agent.aspx) Device Agent makes downloading from your device easy, online or offline. Save workouts to TrainingPeaks.com or WKO+. Free for Mac and PC.

## Usage

```puppet
include trainingpeaks_device_agent
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
