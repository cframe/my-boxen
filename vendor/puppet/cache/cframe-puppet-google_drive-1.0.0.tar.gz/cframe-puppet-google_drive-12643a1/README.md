# Google Drive
[Google Drive](https://tools.google.com/dlpage/drive) Access files on your computer from anywhere.

## Usage

```puppet
include google_drive
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
