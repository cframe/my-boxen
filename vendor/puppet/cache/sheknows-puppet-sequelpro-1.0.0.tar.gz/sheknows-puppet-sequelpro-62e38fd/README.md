# Sequel Pro Puppet Module for Boxen

## Usage

```puppet
include sequelpro
```

## Required Puppet Modules

* boxen
