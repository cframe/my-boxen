require 'spec_helper'

describe 'sequelpro' do
  let(:facts) do
    {
      :boxen_home => '/opt/boxen'
    }
  end

  it do
    should contain_package('Sequel Pro').with({
      :source   => 'http://sequel-pro.googlecode.com/files/sequel-pro-1.0.1.dmg',
      :provider => 'compressed_app'
    })
  end
end
